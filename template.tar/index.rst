.. XXXTITLEXXX documentation master file, created by
   sphinx-quickstart on Mon Jun 13 03:22:58 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to XXXTITLEXXX's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

